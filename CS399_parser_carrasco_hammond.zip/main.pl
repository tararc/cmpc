#!/cygdrive/c/Perl/bin/perl -w

use strict;
our $filename;

#for now we will only hadle one file (the first argument)
if(@ARGV == 0)
{
    die "Input file required.\n";
}
else #assume the first argument is the filename
{
    $filename = $ARGV[0];

    #check for a valid file extension
    if ($filename =~ /^[a-zA-Z0-9\.\/\\_\-]+(.cmi)$/)
    {
		# Call other compiler modules (other perl files):
        system("scanner.pl $filename");
		system("parser.pl tokens.txt");
    }
    else
    {
        die "Invalid file type: '.cmi' extension required!\n";
    }
}

