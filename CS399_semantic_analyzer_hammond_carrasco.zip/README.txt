Usage at commandline:

perl main.pl filename.cmi
